package com.springboot.first.app;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	// Get 
	// http://localhost:8081/student
	@GetMapping("/student")
	public student getStudent() {
		return new student("Rubal","Singla");
	}

}
