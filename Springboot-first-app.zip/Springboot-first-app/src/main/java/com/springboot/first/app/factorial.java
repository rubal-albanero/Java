package com.springboot.first.app;

public class factorial {

	public int getFactorial(int number)
	{
	        long fact = 1;
	        int i = 1;
	        while(i<=number)
	        {
	            fact = fact * i;
	            i++;
	        }
	        return number;
	}
}
