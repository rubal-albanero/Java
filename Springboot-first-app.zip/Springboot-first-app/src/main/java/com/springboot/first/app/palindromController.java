package com.springboot.first.app;

import org.springframework.web.bind.annotation.GetMapping;

public class palindromController {

			// http://localhost:8081/palindrome
			@GetMapping("/palindrome")
			public void getPalindromei() {
				System.out.println(new palindrome().palindromeString("Test String"));
			}
}
