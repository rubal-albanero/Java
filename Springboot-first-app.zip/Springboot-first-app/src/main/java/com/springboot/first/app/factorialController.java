package com.springboot.first.app;

import org.springframework.web.bind.annotation.GetMapping;

public class factorialController {

	// http://localhost:8081/factorial
	@GetMapping("/factorial")
	public void getFactorial() {
		System.out.println(new factorial().getFactorial(5));
	}
}
