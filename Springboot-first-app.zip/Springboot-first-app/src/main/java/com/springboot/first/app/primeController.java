package com.springboot.first.app;

import org.springframework.web.bind.annotation.GetMapping;

public class primeController {

	// http://localhost:8081/primeNumber
	@GetMapping("/getPrimeNo")
	public void getPrimeNo() {
		System.out.println(new primeNumber().getPrimeNo(5));
	}
}
