package com.springboot.first.app;

import org.springframework.web.bind.annotation.GetMapping;

public class FibonacciController {
	
		// http://localhost:8081/fibonacci
		@GetMapping("/fibonacci")
		public int getFibonacci() {
			return new fibonacci().nthFibonacciTerm(20);
		}
}
